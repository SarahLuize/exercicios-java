package com.ifsc.tds;

public class Leao extends Animal {

	@Override
	public void emitirSom() {
		System.out.println("Rugir");
	}
}
