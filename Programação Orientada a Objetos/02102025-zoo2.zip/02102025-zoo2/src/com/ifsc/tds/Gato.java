package com.ifsc.tds;

public class Gato extends Animal{

	@Override
	public void emitirSom() {
		System.out.println("Miar");
		
	}	
}
