#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Ola mundo\n");
    return 0;
}
