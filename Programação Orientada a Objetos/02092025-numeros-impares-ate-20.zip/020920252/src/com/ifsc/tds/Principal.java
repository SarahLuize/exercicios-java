package com.ifsc.tds;

public class Principal {

	public static void main(String[] args) {
		
		for (int i = 0; i < 21; i++) {
			if(i % 2 != 0) {
				System.out.println("N�mero �mpar: " + i);
			}
			
		}

	}

}
