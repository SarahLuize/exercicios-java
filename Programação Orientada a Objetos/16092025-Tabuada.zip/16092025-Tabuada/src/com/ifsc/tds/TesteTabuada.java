package com.ifsc.tds;

public class TesteTabuada {

	public static void main(String[] args) {
		Tabuada tabuada = new Tabuada();
		
		tabuada.Tabuada(2);
		tabuada.Tabuada(7);
	}

}
