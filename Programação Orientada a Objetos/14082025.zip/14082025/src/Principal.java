
public class Principal {

	public static void main(String[] args) {
		System.out.println("Al� Mundo!");
		
		System.out.println("Sarah");

	}

}
