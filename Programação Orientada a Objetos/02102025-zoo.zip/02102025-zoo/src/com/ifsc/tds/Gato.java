package com.ifsc.tds;

public class Gato extends Animal {

	public void miar() {
		System.out.println("Miar");
	}
}
