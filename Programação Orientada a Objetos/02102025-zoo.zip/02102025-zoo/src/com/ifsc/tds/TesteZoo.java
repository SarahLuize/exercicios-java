package com.ifsc.tds;

public class TesteZoo {

	public static void main(String[] args) {
		Gato garfield = new Gato();
		garfield.miar();
		Cachorro rex = new Cachorro();
		rex.latir();
		
	}

}
