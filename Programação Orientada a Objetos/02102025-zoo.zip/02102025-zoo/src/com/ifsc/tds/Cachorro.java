package com.ifsc.tds;

public class Cachorro extends Animal{

	public void latir() {
		System.out.println("Latir");
	}
}
