package com.ifsc.tds;

public class TesteImpares {

	public static void main(String[] args) {
		NumerosImpares numeros = new NumerosImpares();

		numeros.informarNumeros();
		
		numeros.somaImpares();
				
		numeros.multiplicacaoPares();
		
	}

}
