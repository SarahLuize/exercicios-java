package com.ifsc.tds;

public class Tabuada {

	public void calcularTabuada(int numero) {
		for (int i = 1; i <= 10; i++) {
			System.out.println(numero + " X " + (i) + " = " + (numero * i));

		}
	}

}
