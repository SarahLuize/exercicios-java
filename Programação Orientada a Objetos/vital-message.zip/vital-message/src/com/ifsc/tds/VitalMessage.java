package com.ifsc.tds;

import java.util.Random;
import java.util.Scanner;

public class VitalMessage {

    public static void cls() {
        for (int i = 0; i < 50; i++) System.out.println();
    }

    public static int howDifficult(Scanner scanner) {
        System.out.print("How Difficult? (4-10): ");
        int d = scanner.nextInt();
        if (d < 4 || d > 10) {
            return howDifficult(scanner);
        }
        return d;
    }

    public static void delay(int seconds) {
        int start = (int) System.currentTimeMillis(); 
        while ((int) System.currentTimeMillis() - start < seconds * 1000);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        cls();
        System.out.println("------Vital Message-------");

        int d = howDifficult(scanner);
        StringBuilder message = new StringBuilder(d);
        Random random = new Random();

        for (int i = 0; i < d; i++) {
            char c = (char) (random.nextInt(26) + 'A');
            message.append(c);
        }

        cls();
        System.out.println("SEND THIS MESSAGE:\n\n" + message.toString());

        delay(d);

        cls();
        System.out.print("WHAT WAS THE MESSAGE? ");
        String userInput = scanner.next().toUpperCase();

        if (message.toString().equals(userInput)) {
            System.out.println("\nMESSAGE CORRECT");
            System.out.println("\nTHE WAR IS OVER");
        } else {
            System.out.println("\nYOU GOT IT WRONG");
            System.out.println("\nYOU SHOULD HAVE SENT: " + message.toString());
        }

        scanner.close();
    }
}
