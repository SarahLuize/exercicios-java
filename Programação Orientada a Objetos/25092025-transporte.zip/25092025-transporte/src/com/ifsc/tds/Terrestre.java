package com.ifsc.tds;

public class Terrestre extends Transporte{

	private int numRodas;

	public int getNumRodas() {
		return numRodas;
	}

	public void setNumRodas(int numRodas) {
		this.numRodas = numRodas;
	}
}
