package com.ifsc.tds.pessoa;

public class TestePessoa {

	public static void main(String[] args) {
		Pessoa fulano = new Pessoa("Fulano", 0);
		
		fulano.dizerONome();
		fulano.dizerAIdade();
		fulano.fazerAniversario();
		fulano.dizerAIdade();
		
	}

}
