package com.ifsc.tds;

public class TestarAnimais {

	public static void main(String[] args) {
		Mamifero camelo = new Mamifero("Camelo", 150f, 4, "Amarelo", "Terra", 2.0f, "�gua");
		Peixe tubarao = new Peixe("Tubar�o", 300f, 0, "Cinzeto", "Mar", 1.5f, "Barbatanas e cauda");

		camelo.imprimeDados();
		tubarao.imprimeDados();

	}

}
