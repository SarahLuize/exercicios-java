package com.ifsc.tds;

public class Principal {

	public static void main(String[] args) {
		int numero1 = 10;
		int numero2 = 20;
		int soma;
		soma = numero1 + numero2;
		System.out.println("A soma �: " + soma);
	}

}
