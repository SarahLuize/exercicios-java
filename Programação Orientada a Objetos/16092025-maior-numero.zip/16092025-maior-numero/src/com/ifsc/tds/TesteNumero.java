package com.ifsc.tds;

public class TesteNumero {

	public static void main(String[] args) {
		MaiorNumero numeros = new MaiorNumero();
		
		numeros.informeNumeros();
		
		numeros.comparacao();

	}

}
