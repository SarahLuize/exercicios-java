package com.ifsc.tds;

public class MaiorNumero {

	private int Num1;
	private int Num2;
	
	void maiorNumero(int Num1, int Num2){
		if(Num1 > Num2){
			System.out.println("Maior número: " + Num1);
		}
		else {
			System.out.println("Maior número: " + Num2);
		}
		 
	}
	
}
