package com.ifsc.tds;

public class testeMaiorNumero {

	public static void main(String[] args) {
		
		MaiorNumero resultado = new MaiorNumero();
		
		resultado.maiorNumero(2, 5);
		
		resultado.maiorNumero(0, 3);
		
	}

}
