package com.ifsc.tds;

public class testeNumeroDecrescente {

	public static void main(String[] args) {
		NumeroDecrescente resultado = new NumeroDecrescente();
		
		resultado.informeNumero();
		resultado.ordemDecrescente();
	}

}
